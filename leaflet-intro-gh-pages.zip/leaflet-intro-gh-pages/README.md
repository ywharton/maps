leaflet-intro
=============

Leaflet tutorial for Maptime Boston. This is intended to be a fairly verbose, guided walkthrough of some basic Leaflet maps, walking a line somewhere in between dumping code snippets and over-explaining every little piece of JavaScript.

[http://maptimeboston.github.io/leaflet-intro](http://maptimeboston.github.io/leaflet-intro)
